//
//  GarageScene.h
//  Speed Racer
//
//  Created by User-23 on 2.07.15.
//  Copyright (c) 2015 г. User-10. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface GarageScene : SKScene

-(id)initWithSize:(CGSize)size;

@end
