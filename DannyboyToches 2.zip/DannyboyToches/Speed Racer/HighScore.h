//
//  HighScore.h
//  Speed Racer
//
//  Created by User-10 on 7/3/15.
//  Copyright (c) 2015 User-10. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface HighScore : SKScene

-(id)initWithSize:(CGSize)size;


@end
